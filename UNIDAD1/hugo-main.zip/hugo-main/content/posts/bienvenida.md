---
title: "Mi primera entrada"
date: 2025-10-14T10:00:00+02:00
draft: false
---

# ¡Hola Mundo!

Esta es mi **primera entrada** en Hugo.

## ¿Qué es Hugo?

Hugo es un generador de sitios estáticos:

- Rápido
- Fácil de usar
- Basado en Markdown

### Código de ejemplo

Puedes incluir código:
```python
def saludar():
    print("Hola desde Hugo!")
