---
title: "Aprendiendo Hugo"
date: 2025-10-14T11:00:00+02:00
draft: false
---

# Mi experiencia con Hugo

Después de crear mi primer sitio con Hugo, he descubierto que:

## Ventajas de Hugo

1. **Velocidad**: Es extremadamente rápido
2. **Simplicidad**: Usar Markdown es muy fácil
3. **Gratuito**: GitHub Pages es gratis

## Lo que más me gusta

- No necesito base de datos
- Control total del código
- Fácil de mantener

¡Seguiré explorando sus capacidades!
