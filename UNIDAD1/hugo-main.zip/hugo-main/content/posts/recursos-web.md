---
title: "Recursos útiles para desarrollo web"
date: 2025-10-14T12:00:00+02:00
draft: false
---

# Recursos que uso para aprender

## Sitios recomendados

- [MDN Web Docs](https://developer.mozilla.org/) - Documentación web
- [Stack Overflow](https://stackoverflow.com/) - Resolver dudas
- [GitHub](https://github.com/) - Repositorios de código

## Herramientas

- **Hugo** - Generador de sitios estáticos
- **Git** - Control de versiones
- **VS Code** - Editor de código

## Próximos pasos

Quiero aprender más sobre:
- CSS avanzado
- JavaScript moderno
- Diseño responsive
