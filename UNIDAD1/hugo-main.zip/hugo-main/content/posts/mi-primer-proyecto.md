---
title: "Mi primer proyecto con Hugo"
date: 2025-10-14T13:00:00+02:00
draft: false
---

# Cómo creé este sitio

Este sitio web es mi primer proyecto usando Hugo y GitHub Pages.

## Pasos que seguí

1. Instalé Hugo en Ubuntu
2. Creé el sitio básico
3. Añadí el tema Ananke
4. Creé contenido en Markdown
5. Publiqué en GitHub Pages

## Problemas que encontré

Al principio tuve algunos errores de conexión, pero después de configurar 
correctamente el servidor local, todo funcionó perfectamente.

## Conclusión

**Hugo es genial** para crear sitios web rápidos y sin complicaciones.

Lo recomendaría a cualquiera que quiera empezar con desarrollo web.
