---
title: "Acerca de"
date: 2025-10-14T10:00:00+02:00
draft: false
---

# Sobre mí

Hola, soy Jaime y este es mi sitio web personal creado con Hugo.

## ¿Qué encontrarás aquí?

- Artículos sobre tecnología
- Proyectos personales
- Tutoriales y guías

## Contacto

Puedes encontrarme en:
- GitHub: [@jaimeper21](https://github.com/jaimeper21)
- Email: jaimeper2006@gmail.com
